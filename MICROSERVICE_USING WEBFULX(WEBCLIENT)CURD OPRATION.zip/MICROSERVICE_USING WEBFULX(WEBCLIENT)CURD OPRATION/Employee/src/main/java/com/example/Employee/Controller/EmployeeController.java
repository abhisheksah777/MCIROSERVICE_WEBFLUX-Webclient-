package com.example.Employee.Controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.Employee.Entity.Employee;
import com.example.Employee.EntityDTO.ApiResponseDTO;
import com.example.Employee.EntityDTO.DepartmentDTO;
import com.example.Employee.EntityDTO.EmployeeDTO;
import com.example.Employee.Mapper.EmployeeMapper;
import com.example.Employee.Service.EmployeeService;

@RestController
@RequestMapping("/Employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private EmployeeMapper emMapper;

	@Autowired
	private ApiResponseDTO apiResponseDTO;

	@Autowired
	private WebClient webClient;
	private EmployeeDTO updateEmployeeDTO;

	@GetMapping("/{id}")
	public ResponseEntity<ApiResponseDTO> getMethodid(@PathVariable Long id) {
		Employee employee = employeeService.findById(id);
		DepartmentDTO departmentDTO = webClient.get()
				.uri("http://localhost:8082/Department/Code/" + employee.getDeptCode()).retrieve()
				.bodyToMono(DepartmentDTO.class).block();
		EmployeeDTO employeeDTO = emMapper.EmployeetoDTO(employee);
		apiResponseDTO.setEmployee(employeeDTO);
		apiResponseDTO.setDepartment(departmentDTO);
		System.out.println(apiResponseDTO);

		if (apiResponseDTO == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}

		return ResponseEntity.ok(apiResponseDTO);

	}

	@PostMapping()
	public ResponseEntity<ApiResponseDTO> insertEmployee(@RequestBody ApiResponseDTO apiResponseDTO) {
		EmployeeDTO employeeDTO = apiResponseDTO.getEmployee();
		DepartmentDTO departmentDTO = apiResponseDTO.getDepartment();
		DepartmentDTO response = webClient.post().uri("http://localhost:8082/Department").bodyValue(departmentDTO)
				.retrieve().bodyToMono(DepartmentDTO.class).block();
		EmployeeDTO employeedto = employeeService.saveEmployee(employeeDTO);
		apiResponseDTO.setEmployee(employeedto);
		apiResponseDTO.setDepartment(response);
		return new ResponseEntity<ApiResponseDTO>(apiResponseDTO, HttpStatus.CREATED);

	}

	@PutMapping("/{id}")
	public ResponseEntity<ApiResponseDTO> updatedEmployee(@PathVariable Long id,
			@RequestBody ApiResponseDTO apiResponseDTO) {
		EmployeeDTO employeeDTO = apiResponseDTO.getEmployee();
		DepartmentDTO departmentDTO = apiResponseDTO.getDepartment();
		Employee empOptional = employeeService.findById(id);
		if (empOptional.getEmpId() == id) {
			empOptional.setFirstName(employeeDTO.getFirstName());
			empOptional.setLastName(employeeDTO.getLastName());
			empOptional.setEmail(employeeDTO.getEmail());
			empOptional.setLocation(employeeDTO.getLocation());
			empOptional.setDeptCode(employeeDTO.getDeptCode());
			updateEmployeeDTO = employeeService.saveEmployee(emMapper.EmployeetoDTO(empOptional));

		} else {
			updateEmployeeDTO = employeeService.saveEmployee(employeeDTO);
		}
		DepartmentDTO response = webClient.put().uri("http://localhost:8082/Department/" + departmentDTO.getDeptCode())
				.bodyValue(departmentDTO).retrieve().bodyToMono(DepartmentDTO.class).block();
		apiResponseDTO.setEmployee(updateEmployeeDTO);
		apiResponseDTO.setDepartment(response);

		return new ResponseEntity<ApiResponseDTO>(apiResponseDTO, HttpStatus.CREATED);

	}

	@GetMapping()
	public ResponseEntity<List<ApiResponseDTO>> getMethodAll() {
		List<Employee> emp = employeeService.findByall();
		List<EmployeeDTO> emplist = emp
				.stream().map(request -> new EmployeeDTO(request.getEmpId(), request.getFirstName(),
						request.getLastName(), request.getEmail(), request.getLocation(), request.getDeptCode()))
				.collect(Collectors.toList());
		List<DepartmentDTO> departmentFlux = webClient.get().uri("http://localhost:8082/Department").retrieve()
				.bodyToFlux(DepartmentDTO.class).map(request -> new DepartmentDTO(request.getDeptId(),
						request.getDeptName(), request.getDeptDescription(), request.getDeptCode()))
				.collectList().block();

		List<ApiResponseDTO> apiResponseDTOList = emplist.stream().map(employeeDTO -> {
			DepartmentDTO matchedDepartment = departmentFlux.stream()
					.filter(department -> department.getDeptCode().equals(employeeDTO.getDeptCode())).findFirst()
					.orElse(null);
			return new ApiResponseDTO(employeeDTO, matchedDepartment);
		}).collect(Collectors.toList());
		return ResponseEntity.ok(apiResponseDTOList);
	}

}
