package com.example.Employee.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.Entity.Employee;
import com.example.Employee.EntityDTO.EmployeeDTO;
import com.example.Employee.Mapper.EmployeeMapper;
import com.example.Employee.Respository.EmployeeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	@Autowired
	private EmployeeMapper mapper;

	public EmployeeDTO saveEmployee(EmployeeDTO employeeDTO) {
		Employee emp = mapper.DTOtoEmployee(employeeDTO);
		employeeRepo.save(emp);
		return mapper.EmployeetoDTO(emp);
		// TODO Auto-generated method stub

	}

	public Employee findById(Long id) {
		return employeeRepo.findById(id).get();
	}

	public List<Employee> findByall() {
		return employeeRepo.findAll();
	}

}
