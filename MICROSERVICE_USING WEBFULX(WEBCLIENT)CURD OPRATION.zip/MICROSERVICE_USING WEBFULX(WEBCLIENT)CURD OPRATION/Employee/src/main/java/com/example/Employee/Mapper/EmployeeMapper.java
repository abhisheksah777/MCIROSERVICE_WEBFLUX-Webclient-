package com.example.Employee.Mapper;

import org.springframework.stereotype.Component;

import com.example.Employee.Entity.Employee;
import com.example.Employee.EntityDTO.EmployeeDTO;

@Component
public class EmployeeMapper {
	public EmployeeDTO EmployeetoDTO(Employee employee) {

		EmployeeDTO emDto = new EmployeeDTO();
		emDto.setEmpId(employee.getEmpId());
		emDto.setFirstName(employee.getFirstName());
		emDto.setLastName(employee.getLastName());
		emDto.setEmail(employee.getEmail());
		emDto.setLocation(employee.getLocation());
		emDto.setDeptCode(employee.getDeptCode());
		return emDto;

	}

	public Employee DTOtoEmployee(EmployeeDTO emDto) {
		Employee employee = new Employee();
		employee.setEmpId(emDto.getEmpId());
		employee.setFirstName(emDto.getFirstName());
		employee.setLastName(emDto.getLastName());
		employee.setEmail(emDto.getEmail());
		employee.setLocation(emDto.getLocation());
		employee.setDeptCode(emDto.getDeptCode());
		return employee;

	}

}
