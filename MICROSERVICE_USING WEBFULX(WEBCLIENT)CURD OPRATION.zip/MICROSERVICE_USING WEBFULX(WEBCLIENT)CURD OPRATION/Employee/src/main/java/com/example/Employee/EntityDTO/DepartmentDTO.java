package com.example.Employee.EntityDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentDTO {
	private Long deptId;
	private String deptName;
	private String deptDescription;
	private String deptCode;

}
