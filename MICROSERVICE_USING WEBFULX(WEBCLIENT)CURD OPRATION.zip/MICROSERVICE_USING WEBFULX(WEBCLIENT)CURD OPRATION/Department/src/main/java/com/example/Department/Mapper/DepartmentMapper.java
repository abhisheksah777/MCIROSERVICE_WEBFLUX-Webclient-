package com.example.Department.Mapper;

import org.springframework.stereotype.Component;

import com.example.Department.Entity.Department;
import com.example.Department.EntityDTO.DepartmentDTO;

@Component
public class DepartmentMapper {

	public DepartmentDTO departmentToDTO(Department department) {
		DepartmentDTO dto = new DepartmentDTO();
		dto.setDeptId(department.getDeptId());
		dto.setDeptName(department.getDeptName());
		dto.setDeptDescription(department.getDeptDescription());
		dto.setDeptCode(department.getDeptCode());
		return dto;

	}

	public Department DTOtodepartment(DepartmentDTO departmentDTO) {
		Department department = new Department();
		department.setDeptId(departmentDTO.getDeptId());
		department.setDeptName(departmentDTO.getDeptName());
		department.setDeptDescription(departmentDTO.getDeptDescription());
		department.setDeptCode(departmentDTO.getDeptCode());
		return department;

	}

}
