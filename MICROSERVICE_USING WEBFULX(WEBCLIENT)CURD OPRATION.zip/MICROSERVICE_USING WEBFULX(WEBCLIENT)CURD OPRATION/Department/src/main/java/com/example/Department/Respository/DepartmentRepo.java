package com.example.Department.Respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Department.Entity.Department;

public interface DepartmentRepo extends JpaRepository<Department, Long> {

	Optional<Department> findByDeptCode(String depaemetCode);


}
