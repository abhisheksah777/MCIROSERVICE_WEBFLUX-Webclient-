package com.example.Department.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Department.Entity.Department;
import com.example.Department.EntityDTO.DepartmentDTO;
import com.example.Department.Mapper.DepartmentMapper;
import com.example.Department.Respository.DepartmentRepo;

@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepo departmentRepo;
	@Autowired
	private DepartmentMapper departMapper;

	public Department findById(Long id) {
		return departmentRepo.findById(id).get();
	}

	public DepartmentDTO saveDepartment(DepartmentDTO departmentDTO) {
		Department department = departMapper.DTOtodepartment(departmentDTO);
		return departMapper.departmentToDTO(departmentRepo.save(department));
	}

	public Department findByDeparmeCode(String depaetmentCode) {
		// TODO Auto-generated method stub
		return departmentRepo.findByDeptCode(depaetmentCode).get();
	}

	public List<DepartmentDTO> findByDeparmentAll() {
		// TODO Auto-generated method stub\
		 List<Department> departmentList = departmentRepo.findAll();
		return departmentList.stream()
	            .map(department -> new DepartmentDTO(
	                    department.getDeptId(),
	                    department.getDeptName(),
	                    department.getDeptDescription(),
	                    department.getDeptCode()))
	            .collect(Collectors.toList());
	}

}
