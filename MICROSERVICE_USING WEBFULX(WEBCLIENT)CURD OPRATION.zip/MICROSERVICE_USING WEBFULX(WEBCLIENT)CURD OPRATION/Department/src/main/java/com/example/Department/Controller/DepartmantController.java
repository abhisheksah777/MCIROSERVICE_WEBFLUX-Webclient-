package com.example.Department.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Department.Entity.Department;
import com.example.Department.EntityDTO.DepartmentDTO;
import com.example.Department.Mapper.DepartmentMapper;
import com.example.Department.Service.DepartmentService;

@RestController
@RequestMapping("/Department")
public class DepartmantController {

	@Autowired
	private DepartmentService departmentService;
	@Autowired
	private DepartmentMapper emMapper;
	DepartmentDTO updateDepartmentDTO;
//	public EmployeeController(EmployeeService employeeService) {
//		this.employeeService = employeeService;
//	}

	@GetMapping("/{id}")
	public ResponseEntity<DepartmentDTO> getMethodid(@PathVariable Long id) {
		Department department = departmentService.findById(id);

		if (department == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		DepartmentDTO employeeDTO = emMapper.departmentToDTO(department);
		return ResponseEntity.ok(employeeDTO);

	}

	@GetMapping("/Code/{code}")
	public ResponseEntity<DepartmentDTO> getMethodCode(@PathVariable String code) {
		Department department = departmentService.findByDeparmeCode(code);

		if (department == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		DepartmentDTO employeeDTO = emMapper.departmentToDTO(department);
		return ResponseEntity.ok(employeeDTO);

	}

	@PostMapping()
	public ResponseEntity<DepartmentDTO> insertEmployee(@RequestBody DepartmentDTO department) {
		return new ResponseEntity<DepartmentDTO>(departmentService.saveDepartment(department), HttpStatus.CREATED);

	}

	@PutMapping("/{code}")
	public ResponseEntity<DepartmentDTO> updatedEmployee(@PathVariable String code,
			@RequestBody DepartmentDTO department) {
		Department empOptional = departmentService.findByDeparmeCode(code);
		if (empOptional.getDeptCode().equals(code)) {
			empOptional.setDeptName(department.getDeptName());
			empOptional.setDeptDescription(department.getDeptDescription());
			empOptional.setDeptId(department.getDeptId());
			updateDepartmentDTO = departmentService.saveDepartment(emMapper.departmentToDTO(empOptional));

		} else {
			updateDepartmentDTO = departmentService.saveDepartment(department);
		}
		return new ResponseEntity<DepartmentDTO>(updateDepartmentDTO, HttpStatus.CREATED);

	}

	@GetMapping()
	public ResponseEntity<List<DepartmentDTO>> getMethodAll() {
		List<DepartmentDTO> departmentList = departmentService.findByDeparmentAll();
		List<DepartmentDTO> departmentDTOList = (departmentList.stream()
				.map(department -> new DepartmentDTO(department.getDeptId(), department.getDeptName(),
						department.getDeptDescription(), department.getDeptCode())))
				.toList();
		return ResponseEntity.ok(departmentDTOList);

	}

}
